Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1521
Section lab: B01

Fichiers :
✓ README.txt
✓ Q6a.java
✓ Q6b.java
✓ Q8.java

