Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

Fichiers :
✓ README.txt
✓ LinkedList1.java
✓ LinkedList2.java

