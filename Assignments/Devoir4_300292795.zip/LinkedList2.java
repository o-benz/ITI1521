
public class LinkedList2 {

   /**
    * Objects of type Node are linked together into linked lists.
    */
   private static class Node {
      int value;        // value of an item in the list.
      Node next;       // Pointer to the next node in the list.
   }
   
   /**
    * Return a new list containing the same items as the list,
    * but in the reverse order.
    */
    static Node reverse( Node obj ) {
      Node reverse = null;     // reverse will be the reversed list.
      Node p = obj;       // going through the nodes of list.
      Node prev=null,next=null;
      while(p!=null){
         Node current = new Node();
         current.value=p.value;
         current.next=reverse;
         reverse=current;
         p=p.next;
      }
      while (reverse != null) {
         next = reverse.next;
         reverse.next = prev;
         prev = reverse;
         reverse = next;
      }
      reverse = prev;
      return reverse;
   } // end of reverse()
   
   
   /**
    * Displays the items in the list to which the parameter, first, points.
    * They are printed on one line, separated by spaces 
    */
    static void display(Node first) {
      Node p; // For traversing the list.
      p = first;
      while(p!=null)
      {
         System.out.print(p.value+" ");
         p=p.next;
      }
      }
   /**
    * Return the number of zeros that occur in a given linked list of int.
    */
 static int count( Node head ) {
   int count_zeros=0;
   while(head!=null)
   {
           if(head.value==0)
           {
                   count_zeros++;
           }else{
           int num=head.value;
           String st=Integer.toString(num);
           int len=st.length();
           while(len-->0)
           {
                   int d=num%10;
                   num=num/10;
                   if(d==0)
                   {
                           count_zeros++;
                   }
           }
           }
           head=head.next;
   }
   return count_zeros;
   }
 /**
    * Return the number of zeros that occur in a given linked list of int.
    * Uses recursion 
    */
 static int countRecursive( Node head ) {
     if(head==null)
{
        return 0;
}
if(head.value==0)
{
        return (1+countRecursive (head.next));
}
return (zeros_count(head.value)+countRecursive(head.next));
} // end of countRecursive()
   public static int zeros_count(int num)
{
        String st=Integer.toString(num);
        int len=st.length();
        int count=0;
        while(len-->0)
        {
                int d=num%10;
                num=num/10;
                if(d==0)
                {
                        count++;
                }
        }
        return count;
}
   public static void main(String[] args) {
   
      Node list = null;   // A list, initially empty.
      Node reverseList;  // The reversed list.
      
      int count = 0;  //The number of elements in the list
      
      while (true) {
             // add a new node onto the head of the list before repeating.      
          count++;
          if (count == 10)
             break;
          Node head = new Node();  // A new node to add to the list.
          head.value = (int)(Math.random()*100);  // A random item.
          head.next = list;
          list = head;
      }
          
        // Print the current list ; its reverse 
       // and the number of zeros in the list using both count methods
          System.out.print("The list: ");
          display(list);
          System.out.println();
          reverseList = reverse(list);
          System.out.print("The reversed list: ");
          display(reverseList);
          System.out.println();
          System.out.println();
          System.out.print("The number of zeros in the list : ");
          System.out.println(count(list));
          System.out.print("The number of zeros in the list, using recursion : ");
          System.out.println(countRecursive(list));
      
   } // end main()
   
} // end LinkedList2 class
