

public class LinkedList1 {

    /** 
     * The nested class Node.  
     */
    private static class Node {
        String value;   
        Node next;                         
    }

    // Instance variable
    /**
     *  A pointer to the first node in the linked list. 
     *  If the list is empty, the value is null. 
     */  
    private Node head;  
    
    
    /**
     * Searches the list for a specified item.  
     * @param searchItem the item that is to be searched for
     * @return true if searchItem is one of the items in the list or false if not
     */
    public boolean find(String obj) {
   Node p; 
    p = head; 
    while(p!=null) {      
        if(obj.equals(p.value)) {  
            return true;
        }
    }
    return false; 
    } 


    /**
     * Remove a specified item from the list, if that item is present.
     */
    public boolean remove(String obj) {

        if ( head == null ) {
            return false;
        }
        else if (head.value.equals (obj)) {
        head=head.next; 
        return true;
        }
        else {
        Node p;
        p=head;
        while(p.next!=null) {     // iterate until end of list
            if(p.next.value.equals(obj)) { // if string found
                p.next=p.next.next;   // make the current node points to node next of next node
                return true;    
            }
        }
        return false; // string not found
        }
    } 


    public void add(String obj) 
    {

        Node newNode;          // A Node to contain the new item.
        newNode = new Node();
        newNode.value = obj;  // newNode.next is null.

        if ( head == null ) {
            head=newNode;
        }
        else if (head.value.compareTo(obj)>=0) {
        newNode.next=head;
        head=newNode;
        }
        else {
        Node p=head;
        while(p.next!=null && p.next.value.compareTo(obj)<0) {
            p=p.next;
        }
        Node q=p.next;
        p.next=newNode;
        newNode.next=q;
        }
    } 


    /**
     * Returns an array that contains all the elements in the list.
     * If the list is empty, the return value is an array of length zero.
     */
    public String[] getList() {
    String[] elements;  
    int count;
    Node p;
    count = 0;
    p = head;
    while (p!=null) {
        count+=1;
        p=p.next;
    }
    String a[] = new String [count];
    p = head;
    int i=0;
    while (p!=null) {
        a[i]=p.value;
        i+=1;
        p=p.next;
    }
    return a;
    }
} 