Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

Fichiers :
✓ README.txt
✓ Card.java
✓ Deck.java
✓ Player.java

