Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

Fichiers :
✓ README.txt
✓ SequenceMax.java
✓ NombreDivisible.java
✓ SequenceDeDeux.java
✓ NombreDiviseurs.java
✓ Dé.java
✓ SetInt.java
